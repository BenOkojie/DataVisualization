import numpy as np
def modifier(arr):
    #task1
    # question 1
    s = ""
    for i in arr[0:1, [0,-1]][0]:
        s = s + str(i) + ", "
    for i in arr[-1:, [0,-1]][0]:
        s = s + str(i) + ", "
    s = s[:-2]
    print(s)
    print("----------------------")
    # question 2

    randarr = np.random.randint(0, 50, size=len(arr))
    newarr = np.column_stack((arr, randarr))
    print()
    
    print(newarr)
    print("----------------------")
    # question 3
    print(np.flipud(newarr[-2]))
    print()
    print("----------------------")
    # question 4
    t = np.mean(newarr, axis = 0)
    print(np.round(t, 2))
    print()
    print("----------------------")
#task2

# question 1
def grade_stats(arr):
    out1 = np.mean((arr[:,1:]),axis = 0)
    above70 = np.where(out1>7)
    s = " Quizzes with mean above 70%:"
    for i in above70[0]:
        s= s+ " Quiz "+ str(i) +", "
    s = s[:-2]
    print(s)
    print("----------------------")
    # question 2
    out2 = np.mean((arr[:,1:]),axis = 1)
    above79 = np.where(out2>7.9)
    s = "Students with mean above 79%:"
    for i in above79[0]:
        s = s +" " +str(arr[i,0])+ ", "
    s = s[:-2]
    print(s)
    print("----------------------")
    # question 3

    perf = arr[:,-1]
    perfscore = np.where(perf==10)
    s = "Students with 100% in last quiz:"
    for i in perfscore[0]:
        s = s +" " +str(arr[i,0])+ ", "
    s = s[:-2]
    print(s)
    print("----------------------")

def matrix_manipulator(a,b):
   
    a = np.array([[1, 2], [3, 4]])
    b = np.array([[5, 6], [7, 8]])
    a_transpose = np.transpose(a)
    print(a_transpose)
    print("----------------------")
    ab_dot=np.dot(a,b)
    print(ab_dot)
    print("----------------------")
    result = ab_dot + np.transpose(b)
    print(result)


