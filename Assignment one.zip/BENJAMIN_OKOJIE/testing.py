from functions import *
#test1
print("test1")
print("----------------------")
arr = np.array([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16], [17, 18, 19, 20]])
modifier(arr)
#test2
print("test2")
print("----------------------")
arr = np.array([[123456, 9, 8, 0, 2], [234567, 8, 8, 0, 5], [345678, 9, 8, 6, 10], [456789, 8, 7, 7, 10]])
grade_stats(arr)
#test3
print("test3")
print("----------------------")
a = np.array([[1, 2], [3, 4]])
b = np.array([[5, 6], [7, 8]])
matrix_manipulator(a,b)