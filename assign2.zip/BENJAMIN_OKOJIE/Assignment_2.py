import pandas as pd
import numpy as np
#q1
df_csv = pd.read_csv('Assignment2Data.csv')
#q2
print(df_csv.head())
#q3
randarr = np.random.randint(1001,1039, size=5)
filter1 = df_csv["Player ID"].isin(randarr)
print(df_csv[filter1])
#q4
filter2 = df_csv["Won"]>df_csv["Matches"]
#q5
for i in df_csv[filter2].index:
    df_csv = df_csv.drop(i)
#q6
df_csv["Lost"] = df_csv["Matches"] - df_csv["Won"]
#q7
df_csv["Win Percentage"] = (df_csv["Won"]/df_csv["Matches"])*100
#q8
def func(percent):
    if percent>90:
        return "Professional"
    elif percent< 91 and percent>75:
        return "Target"
    else:
        return "Development"
df_csv["Category"] = df_csv["Win Percentage"].map(lambda x: func(x))
#q9
maxfilter = df_csv["Win Percentage"].idxmax()
print(df_csv.loc[maxfilter, "Player ID"])
#q10
minfilter = df_csv["Win Percentage"].idxmin()
print(df_csv.loc[minfilter, "Player ID"])
#q11
grouped = df_csv.sort_values(["Win Percentage"], ascending = 0).groupby("Category")
print(grouped.first())
#q12
groupedcity = df_csv.groupby("City")
agegroup = groupedcity.get_group("Waterloo")

def func(age):
    if age<=20:
        return "20 and below"
    elif age<= 25 and age>20:
        return "20 to 25"
    elif age<30 and age>25:
        return "25-30"
    else:
        return "30+"
agegroup["age group"] = agegroup["Age"].map(lambda x: func(x))
agegroups = agegroup.sort_values(["Win Percentage"], ascending = 0).groupby("age group")
maxval = agegroup.loc[agegroup['Win Percentage'].idxmax(), 'age group']
print(maxval)
#q13
groupedcity = df_csv.groupby("City")
print(groupedcity["Win Percentage"].agg('mean'))
#q14
filterage = df_csv["Age"]>20
print(df_csv[filterage]["Win Percentage"].agg('mean'))
#q15
sortmatch = df_csv.sort_values(["Matches"], ascending = 0)
print(sortmatch)
